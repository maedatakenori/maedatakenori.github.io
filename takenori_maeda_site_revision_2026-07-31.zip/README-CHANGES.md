# Site revision — 2026-07-31

Replace the corresponding HTML files in the root of the artist-site folder.
Back up the current site first.

## Revised files

- `index.html` — concrete opening statement; less abstract authorship language
- `works.html` — shorter, factual Overlay description; no independent right-column scroll
- `incision.html` — makes non-execution a dated archived condition rather than an unfinished proposal
- `fragment.html` — identifies the existing browser archive as **Archive state 01**, removes the independent right-column scroll, reduces explanation, and places optional physical photographs before the generated composition and verification data
- `statement.html` — reduced from nine dense paragraphs to five; removed AGI/cat/crime rhetoric and retained drawing, forged authority, execution gap, error, and temporary composition
- `about.html` — updates Tokyo to Kobe and adds a concise professional bio
- `contact.html` — adds Kobe and expands the inquiry line

## Important: optional images to add

The revised pages remain usable even when these files are absent. Each missing optional image removes only its own figure.

### Fragment
Place photographs in `assets/images/` with these filenames:

1. `fragment-installation.jpg` — overall installation or test installation
2. `fragment-detail.jpg` — close detail of the lines
3. `fragment-verso.jpg` — reverse with timestamps and records
4. `fragment-f05-red-record.jpg` — the red error record
5. `fragment-paper-edge.jpg` — paper edge, deformation, wear, or surface
6. `fragment-working-hand.jpg` — hand during a timed session

The strongest four are installation, detail, verso, and F05 red record. Add those first.

### Incision

1. `incision-source-drawing.jpg` — the intact source drawing
2. `incision-non-execution-declaration.jpg` — a photographed, dated physical declaration

These two photographs help distinguish the work from an unrealised software proposal.

## Fragment archive integrity

The included `fragment.html` deliberately leaves the existing `fragment.js` verification dataset untouched. It now describes that dataset honestly as **Archive state 01: F01–F05, sealed 21 July 2026**. F06 is mentioned as a later state but is not falsely inserted into the five-chain browser verification.

A fully live F01–F06 page requires the corresponding current `fragment.js` / JSON data. Do not change the displayed counts to six until that data is updated and verified.
