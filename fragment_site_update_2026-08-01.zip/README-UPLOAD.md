# Fragment page update — 2026-08-01

## Upload these files

Replace the repository root `fragment.html` with the included file.
Upload the included image files into `assets/images/` and the JSON into `assets/data/`.

Included now:

- `assets/images/fragment-composition-s100-2026-07-21.png`
- `assets/images/fragment-f02-calibration.png`
- `assets/images/fragment-f03a01-verso.jpg`
- `assets/images/fragment-f05-anomaly-log.png`
- `assets/data/composition_S100_2026-07-21.json`

## One optional photograph remains

Add a clean recto photograph later as:

- `assets/images/fragment-f03a01-recto.jpg`

The HTML automatically hides the recto figure while that file is absent. No broken image appears.

## Existing files kept unchanged

The page still loads:

- `assets/css/style.css`
- `assets/js/main.js`
- `assets/js/fragment.js`

The existing session-chain and browser-verification data are retained inside a collapsed “Archive data” section. The old dynamically drawn composition is hidden; the official S100 PNG is displayed instead.
